import android.content.Context;
import android.widget.BaseAdapter;

import java.util.List;

//public class TravelAdapter extends BaseAdapter {
//    private List<TravelData> traverList;
//    private Context context;
//
//}
