package com.example.traveljotter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TravelList_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travel_list);
    }
}